# Core Beliefs
